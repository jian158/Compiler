int inc()
{
    int i=1;
    float j;
    return 0;
}