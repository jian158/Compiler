class Main{

	int main(){
		i=i*5+i/2;
	}

}


